package types

const VERSION = "2.5.0"
