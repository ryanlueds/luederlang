package example_test

import (
	. "github.com/onsi/ginkgo/v2/dsl/core"
)

var _ = Describe("DslCoreFixture", func() {
	Describe("dslcore", func() {
		It("dslcore", func() {
			By("step 1")
			By("step 2")
		})
	})
})
