//go:build windows
// +build windows

package internal

import "os"

var PROGRESS_SIGNALS = []os.Signal{}
