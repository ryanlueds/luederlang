Output of `go run cmd/demo-list/demo.go`:

<img src="../../progress/images/demo.gif" alt="Progress Demo in a Terminal"/>